Mode d'emploi :

Touche A : Donner à Boire de 1
Touche Q : Donner à Manger de 1
Touche S : Recharger la nourriture et l'eau de +1
Touche E : Pillule Bleu, en la consommant vous perdez 1 de nourriture et 2 d'eau mais le morale monte de 1
Touche R : Pillule Rouge, en la consommant vous perdez 2 de nourriture et 1 d'eau mais le baisse du morale est ralenti de 10 secondes
Touche ESPACE : Quitte instantanément le jeu
Touche W : S'amuser, consomme 1 d'eau et 1 de nourriture mais +1 d'amusement (en cours de dev)
